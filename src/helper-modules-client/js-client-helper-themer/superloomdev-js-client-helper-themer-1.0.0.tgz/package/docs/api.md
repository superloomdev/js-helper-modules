# API Reference

Every exported function of `helper-themer`, its arguments, and its return shape. For the validated contracts see [Schemas](schemas.md). For authoring a template see [Template Reference](template.md).

## Loader

```javascript
import themer from '@superloomdev/js-client-helper-themer';

const Themer = themer(shared_libs, config);
```

### Parameters

| Parameter | Type | Description |
|---|---|---|
| `shared_libs` | `Object` | Lib container with Utils and Debug |
| `config` | `Object` | Configuration overrides (optional) |

Each loader call returns an independent instance with its own result cache. A host that renders one theme makes one instance and keeps it.

## Getting Started

The common case is one call at startup:

```javascript
const theme = Themer.buildTheme(template, layers, 'web');

theme.tokens.spacing03;
// '1rem'
```

`buildTheme` is synchronous and does no I/O, so the theme is ready in the same tick and rendering never waits on it.

## The Main Functions

### `buildTheme(template, layers, platform, options)`

Derives a theme and emits it for one platform. Runs `resolve` then `emit`, and carries the derivation reports through.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `template` | `Object` | Yes | The template to derive from |
| `layers` | `Object[]` | Yes | Ordered sparse overlays |
| `platform` | `String` | Yes | `'web'` or `'native'` |
| `options` | `Object` | No | Per-call `contrast`, `min_contrast_ratio`, and `motion_factor` overrides |

```javascript
const theme = Themer.buildTheme(myTemplate, [
  { name: 'brand', tokens: { brand: '#0f62fe' } },
  { name: 'dark', polarity: 'dark' }
], 'native');

theme.tokens.spacing03;    // 16
theme.tokens.code01;       // { fontSize: 12, lineHeight: 16, ... }
theme.substituted;         // tokens replaced by a platform fallback
theme.lossy;               // facts the projection could not carry
theme.corrections;         // contrast rewrites that were applied
```

### `resolve(template, layers, options)`

Derives a platform-independent token map. Use this directly when emitting for both platforms from one derivation, or when inspecting a theme without rendering it.

```javascript
const resolved = Themer.resolve(myTemplate, layers);

resolved.tokens.spacing03;      // 16, canonical and unit-free
resolved.stats.route;           // { literal: 4, alias: 1, rule: 3, ... }
resolved.violations;            // contrast failures that were found
```

Resolution is cached per instance. Calling again with equal layer content returns the same object, which is what makes a framework provider's freshly built array cheap.

### `emit(resolved, template, platform, options)`

Projects a resolved token map onto one platform. Both platforms emit the same token keys. An options argument may be passed for symmetry with `resolve`; a key outside `contrast`, `min_contrast_ratio`, and `motion_factor` throws by name. Malformed template structure and unknown metadata groups throw before cache lookup.

```javascript
const resolved = Themer.resolve(myTemplate, layers);

const web = Themer.emit(resolved, myTemplate, 'web');
const native = Themer.emit(resolved, myTemplate, 'native');

web.tokens.spacing03;      // '1rem'
native.tokens.spacing03;   // 16
```

A token the platform cannot carry takes its declared fallback and is named in `substituted`. A fact the projection cannot represent is named in `lossy`:

```javascript
native.lossy;
// [{ token: 'cardShadow', fact: 'layers', reason: 'React Native supports one shadow, ...' }]
```

### `validateTemplate(template)`

Checks a template's structural shape without deriving from it. **This is the one function here that reports instead of throwing**, because it exists to be called before resolution, and both of its callers want every problem at once.

```javascript
Themer.validateTemplate(myTemplate);
// { success: true, errors: [] }

Themer.validateTemplate({ tokens: 'oops', meta: 'oops' });
// {
//   success: false,
//   errors: [
//     '[helper-themer] template.tokens must be a plain object',
//     '[helper-themer] template.meta must be a plain object'
//   ]
// }
```

Use it at build time to fail a theme package, or in the layer that accepts a theme document from a server. Raising the first finding would turn checking a package into a five-round guessing game, which is why this surface differs from every other one in the module.

Resolution still throws. By the time a template reaches `resolve` it has been checked, so a malformed one is a caller bug rather than a document under review.

## Token Contract

The engine core is vocabulary-agnostic: `buildTheme` accepts any token names. Superloom's vocabulary, the token contract, ships in this package as data and is read through two functions.

### `getContract()`

Returns the frozen token contract registry. Same reference on every call. Never throws.

```javascript
const contract = Themer.getContract();

contract.version;    // contract version string
contract.groups;     // emitter group names
contract.tokens;     // one entry per contract token: { group, emit?, values? }
contract.meta;       // derived metadata, can be attached to a template as template.meta
```

### `validateContract(theme, options)`

Checks `theme.tokens` against the contract. Returns `{ success, errors, warnings }`. Throws `TypeError` only when `theme`, `theme.tokens`, `options.required`, or `options.supported` is malformed; reports every content finding.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `theme` | `Object` | Yes | The theme to check. Must have a `tokens` map |
| `options` | `Object` | No | Validation options |

| Option | Type | Description |
|---|---|---|
| `options.required` | `String[]` | Token names whose absence is an error |
| `options.supported` | `String[]` | Token names whose presence without support is a warning |

```javascript
const result = Themer.validateContract(theme, {
  required: ['color.background', 'color.text_primary'],
  supported: ['color.background', 'color.text_primary', 'spacing.spacing_05']
});

result.success;     // true when errors is empty
result.errors;      // [{ code, token, message }] with codes CONTRACT_MISSING_TOKEN,
                    //   CONTRACT_UNKNOWN_TOKEN, CONTRACT_INVALID_VALUE
result.warnings;    // [{ code, token, message }] with code CONTRACT_UNSUPPORTED_TOKEN
```

Structure and routes are `validateTemplate`'s job; this function checks names and literal value types only. Alias strings are accepted for every type.

## Inspection

### `auditRoles(theme)`

Checks a built theme's color roles against the engine's role rules (`themer.roles.js`). Returns `{ success, findings }`. Throws `TypeError` only when `theme` or `theme.tokens` is malformed; a role the theme lacks is a `missing` finding, not a throw.

Three kinds of rule: `contrast` (a content role on its surface role meets a minimum ratio: 4.5 for text, 3.0 for icons and boundaries; a translucent content color is composited on the surface first, a translucent surface on `color.background`), `distinct` (two roles that mean different things do not share a value: a danger fill equal to the disabled fill is a danger button that reads as disabled, a selected surface equal to the page shows nothing; when `feedback.press` is `highlight`, every hover and active fill also differs from its rest fill, since the fill is what shows the state), and `shadow` (every `shadow.level_*` layer color is translucent). Placeholder text is deliberately not a rule.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `theme` | `Object` | Yes | A built theme (native projection). Must have a `tokens` map |

```javascript
const result = Themer.auditRoles(Themer.buildTheme(profile.schemes.light, [], 'native'));

result.success;     // true when findings is empty
result.findings;    // [{ rule: 'contrast', tokens: [content, surface], ratio, minimum }]
                    // [{ rule: 'distinct', tokens: [a, b], value }]
                    // [{ rule: 'shadow', tokens: [level], value }]
                    // [{ rule: 'missing', tokens: [name] }]
```

A template's tests run this over every built scheme, so a value that would draw an unreadable label is caught at the template, before any component draws it.

### `getPlatforms()`

Lists the platforms this engine emits for.

```javascript
Themer.getPlatforms();
// ['web', 'native']
```

Returns a copy, so a caller cannot mutate the engine's own list.

### `getCacheStats()`

Reports this instance's cache counters.

```javascript
Themer.getCacheStats();
// { hits: 12, misses: 3, evictions: 0, size: 3 }
```

### `clearCache()`

Drops every cached result and resets the counters. Returns nothing.

```javascript
Themer.clearCache();
```

## Failure Behavior

Every failure throws `TypeError`, with `validateTemplate` as the deliberate exception described above. `validateContract` throws `TypeError` for malformed arguments and reports content findings as `{ success, errors, warnings }`. There is no `{ success, error }` **operational** envelope anywhere in this module, because a pure engine has no operational failures to report. The full reasoning is in [Philosophy](philosophy.md); the message format and the complete list are in [Schemas](schemas.md).

```javascript
Themer.emit(resolved, template, 'android');
// TypeError: [helper-themer] platform must be one of: web, native
```

## What This Module Does Not Do

It does not load fonts, fetch themes, read the DOM, or touch React. A type set carries a font family **token** that this engine passes through untranslated; resolving that token to a real family name and loading the file belong to `helper-font`. The two modules do not depend on each other, and theming never waits on a font. See [Philosophy](philosophy.md).
