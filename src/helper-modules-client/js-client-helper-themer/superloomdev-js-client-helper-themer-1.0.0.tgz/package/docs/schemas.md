# Schemas. `helper-themer`

The validated contracts at the module boundary: what a caller must pass and what the engine returns. These contracts are enforced in `themer.validators.js` and are the module's hard edges. For the function reference see [API Reference](api.md). For configuration keys see [Configuration](configuration.md). For the authoring guide see [Template Reference](template.md).

An application that receives a theme document from a server forwards it in exactly these shapes.

## On This Page

- [Throw Versus Return](#throw-versus-return)
- [Naming Convention](#naming-convention)
- [CONFIG Schema](#config-schema)
- [Template Schema](#template-schema)
- [Layer Schema](#layer-schema)
- [Options Schema](#options-schema)
- [Resolution Result Schema](#resolution-result-schema)
- [Template Check Result Schema](#template-check-result-schema)
- [Contract Check Result Schema](#contract-check-result-schema)
- [Emitted Theme Schema](#emitted-theme-schema)
- [What This Module Does Not Validate](#what-this-module-does-not-validate)
- [Error Messages](#error-messages)

---

## Throw Versus Return

| Category | Trigger | Mechanism | When |
|---|---|---|---|
| **Programmer error** | Malformed template, malformed layer, bad option, unknown platform | Throws `TypeError` | At the call, before any derivation |
| **Review finding** | A template submitted to `validateTemplate`, or a theme submitted to `validateContract` | Returns `{ success, errors }` or `{ success, errors, warnings }` | Before resolution, by deliberate choice |

The engine is a pure engine: synchronous derivation with no I/O, no network, and no external state. Its **operational** error set is empty, so there is no `{ success, error }` operational envelope anywhere in this module.

The second row is not an operational envelope. `validateTemplate` and `validateContract` exist to inspect a document that is under review rather than in use, and a reviewer wants every finding at once. Raising the first one makes checking a theme package iterative for no reason. Once a template reaches `resolve`, it has been reviewed, and any remaining defect is a caller bug that throws like everything else.

This places a duty on the host. A theme document arriving over the network is **not** trusted input, and handing a malformed one straight to `resolve` throws. Validate and handle the failure before calling, or wrap the call. The loader module that owns fetching is the correct place for that, because it is the layer that does I/O and therefore has operational errors to report.

---

## Naming Convention

Two conventions meet in this module, and the boundary between them is deliberate.

| Surface | Convention | Why |
|---|---|---|
| Template keys, layer keys, options keys, result keys | `snake_case` | These are this module's own public shapes |
| Scale names and operation names | `camelCase` | These are identifiers naming an engine capability (`stepPairIncrement`, `rampStep`), not data fields |
| Keys **inside** an emitted token value | `camelCase` | These are React Native and CSS-in-JS property names (`fontSize`, `boxShadow`). Renaming them would produce a style object neither platform accepts |

---

## CONFIG Schema

The merged `CONFIG` object passed to the loader. Validated by `validateConfig`. Every key has a default, so `{}` is valid.

| Key | Type | Default | Constraint |
|---|---|---|---|
| `BASE_FONT_SIZE` | `Number` | `16` | Greater than zero. Web emit divides pixel sizes by this to produce rem |
| `CACHE_CAPACITY` | `Number` | `32` | Whole number, one or greater |
| `CACHE_ENABLED` | `Boolean` | `true` | Must be a real boolean, not a truthy value |
| `MIN_CONTRAST_RATIO` | `Number` | `4.5` | Between 1 and 21 inclusive |
| `DEFAULT_TYPE_SCALE` | `String` | `'stepPairIncrement'` | Must name a generator this engine provides |
| `SCALE_GENERATORS` | `Object` | `{}` | Custom scale generator overrides. Keys are scale names, values are generator definitions |

---

## Template Schema

The template passed to `resolve`, `buildTheme`, and `validateTemplate`. Validated by `validateTemplate` for structure; individual token entries are validated during resolution, where the token name is known and can be named in the message.

| Section | Type | Required | Constraint |
|---|---|---|---|
| `tokens` | `Object` | Yes | Map of token name to entry. The one section the engine cannot derive without |
| `meta` | `Object` | No | Map of token name to metadata. A token with no entry is treated as group `raw` |
| `scales` | `Object` | No | Seed values per named scale |
| `scales.base_font_size` | `Number` | No | Greater than zero. Overrides `CONFIG.BASE_FONT_SIZE` for this template |
| `palette` | `Object` | No | Flat map of palette name to hex. The operand pool for `hue` rules and contrast snapping |
| `ramp` | `String[]` | No | Ordered neutral ramp, lightest first. Required only if a `rampStep` rule is used |
| `polarity` | `String` | No | `'light'` or `'dark'`. Defaults to `'light'` |
| `contrast_rules` | `Array[]` | No | Each entry is `[token_name, background_token_name, min_ratio]` |

### Token entry shapes

A token entry takes one of nine shapes. The engine dispatches on shape, and nothing downstream can tell which route produced a value.

| Route | Shape | Example |
|---|---|---|
| **Literal** | String, number, boolean, or array | `'#0f62fe'`, `110`, `[0.2, 0, 0.38, 0.9]` |
| **Alias** | String wrapped in braces | `'{brand}'` |
| **Rule** | Object with `op` and `args` | `{ op: 'rampStep', args: [5] }` |
| **Generator** | Object with `scale` | `{ scale: 'miniUnit', multiplier: 2 }` |
| **Type set** | Object with `type_set: true` | `{ type_set: true, step: 1, weight: 400, line_height: 1.33333 }` |
| **Shadow** | Object with `shadow: true` | `{ shadow: true, layers: [ { x: 0, y: 2, blur: 4, spread: 3, color: '#00000033' } ] }` |
| **Viewport** (v2) | Object with `viewport: true` | `{ viewport: true, vw: 2 }` |
| **Spring** (v2) | Object with `spring: true` | `{ spring: true, stiffness: 700, damping: 47.62, mass: 1 }` |
| **Segments** (v2) | Object with `segments: true` | `{ segments: true, curves: [[0.5, [0.05, 0.7, 0.1, 1]], [1, [0.3, 0, 0.8, 0.15]]] }` |
| **Icon** (v4) | Object with `icon: true` | `{ icon: true, viewBox: '0 0 32 32', paths: [{ d: 'M8 8h16v16H8z', fillRule: 'evenodd' }], sizes: { '16': { viewBox: '0 0 16 16', paths: [{ d: 'M4 4h8v8H4z' }] } } }` |

### Type set fields

| Field | Type | Required | Note |
|---|---|---|---|
| `type_set` | `Boolean` | Yes | Must be `true`. Distinguishes a type set from a generator, since both name a scale |
| `step` | `Number` | One of `step` or `font_size` | Position on the type scale. Conflicts with `font_size` |
| `scale` | `String` | No | Defaults to `stepPairIncrement`; valid only with `step` |
| `font_size` | `Number` or alias | One of `font_size` or `step` | Exact unit-free size. Finite and greater than zero; never rounded |
| `line_height` | `Number` | No | Unitless ratio. Zero or greater; conflicts with `line_height_px` |
| `line_height_px` | `Number` or alias | No | Exact unit-free absolute line height. Finite and zero or greater; conflicts with `line_height` |
| `letter_spacing` | `Number` | No | Unit-free spacing; omitted from output when absent |
| `weight` | `Number` | No | Omitted from emit when absent, never stringified |
| `font_family` | `String` | No | A **token**, never a family name and never a font stack |

### Shadow fields

| Field | Type | Required | Note |
|---|---|---|---|
| `shadow` | `Boolean` | Yes | Must be `true` |
| `layers` | `Object[]` | Yes | Explicit geometry. Each entry is `{ x, y, blur, spread, color, inset? }` |
| `inset` | `Boolean` | No | Paints the layer inside the border box; defaults to false |

Layer geometry validation:

| Field | Type | Constraint |
|---|---|---|
| `x` | `Number` | Finite. May be negative |
| `y` | `Number` | Finite. May be negative |
| `blur` | `Number` | Finite, zero or greater. Negative blur is rejected |
| `spread` | `Number` | Finite. May be negative |
| `color` | `String` | Required. Hex or rgb/rgba. Accepts `#RGB`, `#RGBA`, `#RRGGBB`, `#RRGGBBAA`, `rgb(R, G, B)`, or `rgba(R, G, B, A)`. RGB channels are integers from 0 through 255; alpha is between 0 and 1; percentages and other CSS color syntaxes are unsupported. Invalid arithmetic input throws |

### Viewport fields (v2)

A viewport literal carries a fluid spacing value in viewport-width units.

| Field | Type | Required | Constraint |
|---|---|---|---|
| `viewport` | `Boolean` | Yes | Must be `true` |
| `vw` | `Number` | Yes | Finite, zero or greater |

No other keys are allowed. Web emit produces `String(vw) + 'vw'`; native emit returns the object unchanged.

### Spring fields (v2)

A spring literal carries React Native `Animated.spring` physics parameters.

| Field | Type | Required | Constraint |
|---|---|---|---|
| `spring` | `Boolean` | Yes | Must be `true` |
| `stiffness` | `Number` | Yes | Finite, greater than zero |
| `damping` | `Number` | Yes | Finite, greater than zero. A coefficient, not a damping ratio. Where source data provides a ratio, `damping = ratio * 2 * Math.sqrt(stiffness * mass)` |
| `mass` | `Number` | Yes | Finite, greater than zero |

No other keys are allowed. Both web and native emit return the object unchanged.

### Segments fields (v2)

A segments literal carries an ordered list of bezier curves with split points.

| Field | Type | Required | Constraint |
|---|---|---|---|
| `segments` | `Boolean` | Yes | Must be `true` |
| `curves` | `Array` | Yes | At least one entry. Each entry is `[t, [x1, y1, x2, y2]]` where `t` is finite in `[0, 1]`, strictly increasing across entries, and the inner array is exactly four finite numbers |

No other keys are allowed.

### Metadata fields

| Field | Type | Required | Note |
|---|---|---|---|
| `group` | `String` | No | Selects the emitter: `color`, `dimension`, `fontSize`, `letterSpacing`, `duration`, `easing`, `typeSet`, `shadow`, `raw`, `spring`, `viewport`. An unknown group is a build-time `TypeError` naming every offending token, not a silent pass-through |
| `platforms` | `String[]` | No | Platforms this token is available on. Defaults to all |
| `fallback` | `Object` | Required when `platforms` excludes a platform | Value to substitute per excluded platform |

---

## Layer Schema

Layers are applied in array order, so the last layer to pin a token wins. Every field is optional; an empty layer is valid and contributes nothing.

| Field | Type | Constraint |
|---|---|---|
| `name` | `String` | Free-form label, used in no logic |
| `tokens` | `Object` | Sparse map of token name to entry, in any of the six shapes |
| `scales` | `Object` | Sparse seed overrides. Named scale seed objects merge by key; `base_font_size` replaces the scalar root size and must be finite and greater than zero |
| `polarity` | `String` | `'light'` or `'dark'` |
| `motion_factor` | `Number` | Between 0 and 1 inclusive. Scales every token in the `duration` group |

A layer must be a plain object. A non-object entry throws and names its index.

---

## Options Schema

The optional per-call bundle passed to `resolve` and `buildTheme`.

| Key | Type | Default | Constraint |
|---|---|---|---|
| `contrast` | `String` | `'correct'` | `'correct'` rewrites failing colors; any other value only reports them |
| `min_contrast_ratio` | `Number` | `CONFIG.MIN_CONTRAST_RATIO` | Between 1 and 21 inclusive |
| `motion_factor` | `Number` | From the layer stack | Between 0 and 1 inclusive. An explicit per-call value, including zero, overrides the layer factor |

Any key outside these three throws by name. Omitted options produce output identical to the existing three-argument call. The cache key is the resolved-object identity, template identity, and platform string. Two calls with semantically equivalent options (one omitted, one explicitly defaulted) share a cache entry.

---

## Resolution Result Schema

Returned by `resolve`.

| Key | Type | Description |
|---|---|---|
| `tokens` | `Object` | Canonical, unit-free value per token name |
| `scales` | `Object` | Merged scale seeds after the cascade |
| `polarity` | `String` | Effective polarity |
| `anchor_index` | `Number` | Ramp position the background occupies |
| `motion_factor` | `Number` | Factor applied to durations |
| `contrast_mode` | `String` | Mode the pass ran in |
| `stats.route` | `Object` | Count per route: `literal`, `alias`, `rule`, `generator`, `type_set`, `shadow` |
| `stats.source` | `Object` | Count per source: `theme`, `default` |
| `corrections` | `Object[]` | Contrast rewrites that were applied |
| `violations` | `Object[]` | Contrast failures that were found, whether or not corrected |

Route is **how** a value was produced; source is **where** the entry came from. Conflating them hides which parts of the chain a theme actually uses.

---

## Template Check Result Schema

Returned by `validateTemplate`. Never throws, including when the argument is not an object.

| Key | Type | Description |
|---|---|---|
| `success` | `Boolean` | True when no finding was recorded |
| `errors` | `String[]` | Every finding, in the order found, in the standard message format |

A non-object template is reported as a single finding, because there are no fields left to go on checking.

---

## Contract Check Result Schema

Returned by `validateContract`. Throws `TypeError` only for a malformed `theme`, `theme.tokens`, `options.required`, or `options.supported`; every content finding is reported.

| Key | Type | Description |
|---|---|---|
| `success` | `Boolean` | True when `errors` is empty. Warnings do not affect success |
| `errors` | `Object[]` | Findings with `CONTRACT_MISSING_TOKEN`, `CONTRACT_UNKNOWN_TOKEN`, or `CONTRACT_INVALID_VALUE` |
| `warnings` | `Object[]` | Findings with `CONTRACT_UNSUPPORTED_TOKEN` |

Each entry is `{ code, token, message }`. `validateContract` checks token names and literal value types against the contract; structure and routes are `validateTemplate`'s job. Alias strings are accepted for every type.

---

## Emitted Theme Schema

Returned by `emit`. `buildTheme` returns the same three keys plus `corrections`, `violations`, and `stats` carried through from resolution.

| Key | Type | Description |
|---|---|---|
| `tokens` | `Object` | Platform-ready value per token name |
| `substituted` | `Object[]` | Tokens the platform cannot carry, replaced by their declared fallback |
| `lossy` | `Object[]` | Facts a projection could not carry. Empty for every current emitter; kept so a future emitter that must drop a fact has somewhere to say so |

Both platforms emit **the same token keys**. A token unavailable on a platform takes its fallback rather than disappearing, because omitting the key would force every caller to guard against `undefined`.

A `lossy` entry carries `token`, `fact`, and `reason`. A value that vanishes with no record is the failure this reporting exists to prevent.

---

## What This Module Does Not Validate

Stated explicitly, because the gaps are deliberate rather than oversights.

- **Whether a `font_family` token names a real typeface.** The engine has no font registry and does no I/O. It emits the token unchanged; `helper-font` resolves it to a registered family name. See [Philosophy](philosophy.md) for why the two modules do not depend on each other.
- **Whether an unused literal color is valid.** Literal tokens pass through without arithmetic validation. When color arithmetic, shadow composition, or contrast reads a value, the engine validates the supported hex/rgb/rgba grammar and throws on malformed input.
- **Whether a theme document came from a trusted source.** Schema shape is not provenance.
- **Whether the emitted values look right.** Contrast rules are the only aesthetic constraint the engine enforces.

---

## Error Messages

Every throw follows the framework's programmer-error format: an alias prefix, the field path that is wrong, and the constraint it failed.

```text
[helper-themer] <field-path> <expected-shape>
```

| Example | Cause |
|---|---|
| `[helper-themer] template must be a plain object` | Template argument was null or a non-object |
| `[helper-themer] template.tokens must be a plain object` | Token map missing |
| `[helper-themer] layers must be an array of layer objects` | Layers argument was not an array |
| `[helper-themer] layers[1] must be a plain object` | One layer entry was not an object |
| `[helper-themer] tokens.brand must be a declared token or alias target` | An alias named a token nothing declares |
| `[helper-themer] tokens.loopA resolves through an alias cycle` | Aliases form a loop |
| `[helper-themer] tokens.pad.scale must name a generator this engine provides` | Unknown scale name |
| `[helper-themer] tokens.brand.op must name an operation this engine provides` | Unknown operation name |
| `[helper-themer] platform must be one of: web, native` | Unknown emit target |
| `[helper-themer] tokens bad (group: nonsense) must name a known emitter group` | Token metadata names a group no emitter table recognizes |
| `[helper-themer] options.mode must be one of: contrast, min_contrast_ratio, motion_factor` | An option key this engine does not define |
| `[helper-themer] options.required must be an array of strings` | `validateContract` received a `required` or `supported` list that is not an array of strings |
| `[helper-themer] color must be a supported numeric color` | Color arithmetic received malformed or unsupported color syntax |
| `[helper-themer] color must have an opaque compositing background` | Contrast rule named a translucent background without a further backdrop |
| `[helper-themer] CONFIG.CACHE_CAPACITY must be a whole number of 1 or greater` | Misconfigured at load time |

`validateContract` returns its findings as `{ code, token, message }` entries rather than formatted strings:

| Code | Severity | Cause |
|---|---|---|
| `CONTRACT_MISSING_TOKEN` | Error | A token in `options.required` is absent from `theme.tokens` |
| `CONTRACT_UNKNOWN_TOKEN` | Error | `theme.tokens` contains a token the contract does not define |
| `CONTRACT_INVALID_VALUE` | Error | A token's literal value does not match its contract type |
| `CONTRACT_UNSUPPORTED_TOKEN` | Warning | A token in `theme.tokens` is not in `options.supported` |

The expected-shape clauses live in `themer.errors.js`, so the format stays in one place and every message reads alike.
