// Info: Themer - a token engine that derives a complete design-token theme
// from a template plus a cascade of layers, then emits it for web and for
// React Native from that one resolved source.
//
// The engine is pure: synchronous derivation, no I/O, no network, no external
// state. It never loads a font, never fetches a theme, and never observes
// whether a typeface is ready. A type set carries a font family TOKEN, which
// the font module resolves to a registered family name on its own timeline.
// Nothing here waits on that, so text renders immediately in a fallback family
// and swaps when the font module is done.
//
// Compatibility: Node.js 24+ and React Native (Hermes). No React, no DOM.
//
// Factory pattern: each loader call returns an independent instance with its
// own result cache. A host that renders one theme makes one instance and keeps
// it; a build tool that sweeps many themes makes one and discards it.
import CONFIG_DEFAULTS from './themer.config.js';
import ERRORS from './themer.errors.js';
import createValidators from './themer.validators.js';
import createColor from './parts/color.js';
import createScale from './parts/scale.js';
import createEmit from './parts/emit.js';
import createResolve from './parts/resolve.js';
import contract from './themer.contract.js';
import ROLES from './themer.roles.js';


/////////////////////////// Module-Loader START ////////////////////////////////

/********************************************************************
Factory loader. One call returns one independent instance with its
own config and its own result cache.

@param {Object} shared_libs - Lib container with Utils and Debug
@param {Object} config - Overrides merged over module config defaults

@return {Object} - Public Themer interface
*********************************************************************/
export default function loader (shared_libs, config) {

  // Dependencies for this instance
  const Lib = {
    Utils: shared_libs.Utils,
    Debug: shared_libs.Debug
  };

  // Merge overrides over defaults
  const CONFIG = Object.assign(
    {},
    CONFIG_DEFAULTS,
    config || {}
  );

  // Color depends on nothing but Lib, so it builds first and serves the validators
  const Color = createColor(Lib, CONFIG, ERRORS);

  // Validators instance - Lib, ERRORS, and Color captured independently here
  const Validators = createValidators(Lib, ERRORS, Color);

  // Validate config immediately so misconfiguration fails at startup
  Validators.validateConfig(CONFIG);

  // Build the pure parts, threading siblings through the uniform parts container
  const Parts = _Themer.buildParts(Lib, CONFIG, ERRORS, Validators, Color);

  // Validate DEFAULT_TYPE_SCALE names a known generator after merge with SCALE_GENERATORS
  // This check runs after buildParts so the Scale part is available with custom generators
  Parts.Scale.byName(CONFIG.DEFAULT_TYPE_SCALE, 'CONFIG.DEFAULT_TYPE_SCALE');

  // Mutable per-instance state (the result cache lives here)
  const state = {
    cache: new Map(),
    object_ids: new WeakMap(),
    next_object_id: 0,
    hits: 0,
    misses: 0,
    evictions: 0
  };

  return createInterface(Lib, CONFIG, ERRORS, Validators, Parts, state);

};/////////////////////////// Module-Loader END /////////////////////////////////



/////////////////////////// createInterface START //////////////////////////////

/********************************************************************
Builds the public interface for one instance. Public and private
functions close over the provided Lib, CONFIG, ERRORS, Validators,
Parts, and state.

@param {Object} Lib - Dependency container
@param {Object} CONFIG - Merged config for this instance
@param {Object} ERRORS - Frozen error catalog
@param {Object} Validators - Validators singleton
@param {Object} Parts - Pure parts built by the loader
@param {Object} state - Mutable per-instance state

@return {Object} - Public Themer interface
*********************************************************************/
const createInterface = function (Lib, CONFIG, ERRORS, Validators, Parts, state) {

  const Themer = {


    // ~~~~~~~~~~~~~~~~~~~~ Theme Building ~~~~~~~~~~~~~~~~~~~~
    // The two stages, and the one call that runs both.

    /********************************************************************
    Derive a theme and emit it for one platform.

    This is the call a host makes at startup. It is synchronous and
    does no I/O, so a theme is ready in the same tick and rendering
    never waits on it.

    @param {Object} template - The template to derive from
    @param {Object[]} layers - Ordered sparse overlays
    @param {String} platform - 'web' or 'native'
    @param {Object} [options] - Per-call overrides

    @return {Object} - Emitted theme
    @return {Object} .tokens - Platform-ready value per token name
    @return {Object} .levels - { 2: {...}, 3: {...} }: the level-2 and
      level-3 readings of every token whose authored value reaches a
      member of a contract leveled set through its alias chain
    @return {Object[]} .substituted - Tokens replaced by a platform fallback
    @return {Object[]} .lossy - Facts a platform projection could not carry
    @return {Object[]} .corrections - Contrast rewrites that were applied
    @return {Object[]} .violations - Contrast failures that were found
    *********************************************************************/
    buildTheme: function (template, layers, platform, options) {

      // The variant selection (v9) becomes real layers once, so resolution
      // and the leveled readings see the identical cascade
      Validators.validateOptions(options);
      const effective = _Themer.effectiveLayers(Lib, template, layers, options);

      // Split options into resolve-side bundle; the adaptive keys were
      // consumed by the cascade computation above
      const resolveOpts = options ? {
        contrast: options.contrast,
        min_contrast_ratio: options.min_contrast_ratio,
        motion_factor: options.motion_factor
      } : undefined;

      // Resolve first, so the emitted result and the reports share one derivation
      const resolved = Themer.resolve(template, effective, resolveOpts);

      // Project the resolved tokens onto the requested platform
      const emitted = Themer.emit(resolved, template, platform);

      // The leveled readings derive from the same resolution, so their
      // losses append to a copy rather than the (possibly cached) list
      const level_lossy = [];
      const levels = _Themer.buildLevels(Lib, Parts, CONFIG, template, effective, resolved, platform, level_lossy);

      // Carry the contrast reports through, since they belong to the derivation
      return {
        tokens: emitted.tokens,
        levels: levels,
        substituted: emitted.substituted,
        lossy: emitted.lossy.concat(level_lossy),
        corrections: resolved.corrections,
        violations: resolved.violations,
        stats: resolved.stats
      };

    },


    /********************************************************************
    Derive a platform-independent token map.

    @param {Object} template - The template to derive from
    @param {Object[]} layers - Ordered sparse overlays
    @param {Object} [options] - Per-call overrides

    @return {Object} - Resolution result, as documented in schemas
    *********************************************************************/
    resolve: function (template, layers, options) {

      // Validate before any property read, so a bad argument names itself
      Validators.validateTemplate(template);
      Validators.validateLayers(layers);
      Validators.validateOptions(options);

      // Validate emitter group names so an unknown group fails loudly at build
      // time rather than silently passing through unprojected
      Validators.validateGroups(template.meta, Parts.Emit.groups());

      // The adaptive selection (v9) becomes real layers before anything
      // reads the cascade; the resolve part never sees the option keys
      const effective = _Themer.effectiveLayers(Lib, template, layers, options);
      const runOpts = _Themer.resolveOptions(Lib, options);

      // Serve a cached derivation when this instance has produced it already
      const key = _Themer.resolveKey(state, template, effective, runOpts);
      const cached = _Themer.getCache(state, key);

      // Cache hit: return the earlier derivation untouched
      if (cached) {
        return cached;
      }

      // Derive, then store under the key so an equal call hits next time
      const result = Parts.Resolve.run(template, effective, runOpts);
      _Themer.writeCache(state, CONFIG, key, result);

      return result;

    },


    /********************************************************************
    Project a resolved token map onto one platform.

    A token unavailable on the target platform takes its declared
    fallback rather than disappearing, and any fact a projection
    cannot carry is reported rather than dropped.

    @param {Object} resolved - Output of resolve
    @param {Object} template - The template that produced it
    @param {String} platform - 'web' or 'native'
    @param {Object} [options] - Per-call options: contrast, min_contrast_ratio, motion_factor

    @return {Object} - Emitted result
    @return {Object} .tokens - Platform-ready value per token name
    @return {Object[]} .substituted - Tokens replaced by a platform fallback
    @return {Object[]} .lossy - Facts the projection could not carry
    *********************************************************************/
    emit: function (resolved, template, platform, options) {

      // Validate the platform so an unknown target fails instead of passing values through
      Validators.validatePlatform(platform, Parts.Emit.platforms());
      Validators.validateTemplate(template);
      Validators.validateGroups(template.meta, Parts.Emit.groups());
      Validators.validateOptions(options);

      // Serve a cached projection when this resolved/template/platform combo was emitted before
      const key = _Themer.emitKey(state, resolved, template, platform);
      const cached = _Themer.getCache(state, key);

      // Cache hit: return the earlier projection untouched
      if (cached) {
        return cached;
      }

      // Project every token, collecting substitutions and losses as it goes
      const result = _Themer.project(Lib, Parts, CONFIG, resolved, template, platform);
      _Themer.writeCache(state, CONFIG, key, result);

      return result;

    },


    // ~~~~~~~~~~~~~~~~~~~~ Inspection ~~~~~~~~~~~~~~~~~~~~
    // What a host needs to check a template or watch the cache.

    /********************************************************************
    Check a template's structural shape without deriving from it.

    Reports rather than throws, and is the one function here that
    does. It exists to be called before resolution by a build tool
    or by a host accepting a theme document, and both want every
    problem at once: raising the first finding turns checking a
    theme package into a five-round guessing game.

    Resolution keeps throwing, because by then a malformed template
    is a caller bug rather than a document under review.

    @param {Object} template - The template to check

    @return {Object} - Check result
    @return {Boolean} .success - True when no finding was recorded
    @return {String[]} .errors - Every finding, in the order found
    *********************************************************************/
    validateTemplate: function (template) {

      // Delegate so the rules live in exactly one place
      return Validators.checkTemplate(template);

    },


    /********************************************************************
    Return the Superloom token contract registry.

    The registry is a frozen object with version, groups, tokens, and
    meta. Component libraries consume subsets of it through
    validateContract. The same reference is returned on every call.

    @return {Object} - Frozen contract registry
    *********************************************************************/
    getContract: function () {

      // Return the frozen registry; the import is already immutable
      return contract;

    },


    /********************************************************************
    Validate a resolved theme against the token contract.

    Returns { success, errors, warnings }. Throws TypeError only when
    theme, theme.tokens, options.required, or options.supported is malformed; reports every
    content finding.

    @param {Object} theme - A theme object with a tokens map
    @param {Object} [options] - Validation options
    @param {String[]} [options.required] - Token names that must be present
    @param {String[]} [options.supported] - Token names this consumer supports

    @return {Object} - Validation result
    @return {Boolean} .success - True when errors is empty
    @return {Object[]} .errors - One entry per contract error
    @return {Object[]} .warnings - One entry per unsupported token warning
    *********************************************************************/
    validateContract: function (theme, options) {

      // Delegate to the validator, threading the contract registry
      return Validators.validateContract(theme, options, contract);

    },


    /********************************************************************
    Audit a built theme's color roles against the engine's role rules:
    every content role reads on its surface role, roles that mean
    different things resolve to different values (and, under highlight
    press feedback, every hover and active fill differs from its rest),
    and every shadow level is translucent. A template test runs this over every scheme
    so a value that would draw an unreadable label, or a danger button
    that reads as disabled, is caught before any component draws it.

    Returns { success, findings }. Throws TypeError only when theme or
    theme.tokens is malformed; a missing token is a finding.

    @param {Object} theme - A built theme with a tokens map (native projection)

    @return {Object} - Audit result
    @return {Boolean} .success - True when findings is empty
    @return {Object[]} .findings - One entry per failed rule:
      { rule: 'contrast', tokens: [content, surface], ratio, minimum } |
      { rule: 'distinct', tokens: [a, b], value } |
      { rule: 'distinct', tokens: [selContainer, selInk, restContainer, restInk], value: [v1, v2] } |
      { rule: 'shadow', tokens: [level], value } |
      { rule: 'missing', tokens: [name] }
    *********************************************************************/
    auditRoles: function (theme) {

      // Argument shape is a caller bug, so it throws
      if (!Lib.Utils.isObject(theme) || Array.isArray(theme) || !Lib.Utils.isObject(theme.tokens) || Array.isArray(theme.tokens)) {
        throw new TypeError('[helper-themer] theme.tokens ' + ERRORS.MUST_BE_PLAIN_OBJECT);
      }
      const tokens = theme.tokens;
      const findings = [];
      const missing = {};
      const present = function (name) {
        if (Lib.Utils.isString(tokens[name])) {
          return true;
        }
        if (missing[name] !== true) {
          missing[name] = true;
          findings.push({ rule: 'missing', tokens: [name] });
        }
        return false;
      };

      // A translucent surface is seen over the page background
      const surfaceOf = function (name) {
        const surface = Parts.Color.parseHex(tokens[name]);
        if (surface.a === 1 || !present('color.background')) {
          return tokens[name];
        }
        const page = Parts.Color.parseHex(tokens['color.background']);
        return Parts.Color.toHex({
          r: surface.r * surface.a + page.r * (1 - surface.a),
          g: surface.g * surface.a + page.g * (1 - surface.a),
          b: surface.b * surface.a + page.b * (1 - surface.a),
          a: 1
        });
      };

      // Contrast: the content composited on its surface meets the minimum
      for (const rule of ROLES.contrast) {
        if (!present(rule[0]) || !present(rule[1])) {
          continue;
        }
        const ratio = Parts.Color.contrastRatio(tokens[rule[0]], surfaceOf(rule[1]));
        if (ratio < rule[2]) {
          findings.push({ rule: 'contrast', tokens: [rule[0], rule[1]], ratio: Math.round(ratio * 100) / 100, minimum: rule[2] });
        }
      }

      // Distinct: two roles with different meanings do not share a value; under
      // highlight press feedback a hover or active fill also differs from its rest
      const distinct = tokens['feedback.press'] === 'highlight' ? ROLES.distinct.concat(ROLES.distinct_highlight) : ROLES.distinct;
      for (const pair of distinct) {
        if (!present(pair[0]) || !present(pair[1])) {
          continue;
        }
        if (Parts.Color.toHex(Parts.Color.parseHex(tokens[pair[0]])) === Parts.Color.toHex(Parts.Color.parseHex(tokens[pair[1]]))) {
          findings.push({ rule: 'distinct', tokens: [pair[0], pair[1]], value: tokens[pair[0]] });
        }
      }

      // Selected pairs: the container and ink a control paints when selected
      // must not both equal their rest paints, or selection shows nothing
      for (const pair of ROLES.selected_pairs) {
        if (!present(pair[0]) || !present(pair[1]) || !present(pair[2]) || !present(pair[3])) {
          continue;
        }
        if (Parts.Color.toHex(Parts.Color.parseHex(tokens[pair[0]])) === Parts.Color.toHex(Parts.Color.parseHex(tokens[pair[2]])) &&
            Parts.Color.toHex(Parts.Color.parseHex(tokens[pair[1]])) === Parts.Color.toHex(Parts.Color.parseHex(tokens[pair[3]]))) {
          findings.push({ rule: 'distinct', tokens: [pair[0], pair[1], pair[2], pair[3]], value: [tokens[pair[0]], tokens[pair[1]]] });
        }
      }

      // Shadow: every layer color of every level is translucent
      for (const level of ROLES.shadow_levels) {
        const value = tokens[level];
        const list = Lib.Utils.isObject(value) && Lib.Utils.isString(value.boxShadow) ? value.boxShadow : null;
        if (list === null) {
          findings.push({ rule: 'missing', tokens: [level] });
          continue;
        }
        const colors = list.match(/rgba?\([^)]*\)|#[0-9a-fA-F]{3,8}/g) || [];
        const opaque = colors.some(function (c) {
          return Parts.Color.parseHex(c).a === 1;
        });
        if (colors.length === 0 || opaque) {
          findings.push({ rule: 'shadow', tokens: [level], value: list });
        }
      }

      return { success: findings.length === 0, findings: findings };

    },


    /********************************************************************
    List the platforms this engine emits for.

    @return {String[]} - Platform names
    *********************************************************************/
    getPlatforms: function () {

      // Delegate to the emit part, which owns the platform tables
      return Parts.Emit.platforms();

    },


    /********************************************************************
    Report this instance's cache counters.

    @return {Object} - Cache counters
    @return {Number} .hits - Calls served from the cache
    @return {Number} .misses - Calls that had to derive
    @return {Number} .evictions - Entries dropped to stay within capacity
    @return {Number} .size - Entries currently held
    *********************************************************************/
    getCacheStats: function () {

      // Copy so a caller cannot mutate the live counters
      return {
        hits: state.hits,
        misses: state.misses,
        evictions: state.evictions,
        size: state.cache.size
      };

    },


    /********************************************************************
    Drop every cached result and reset the counters.

    @return {void}
    *********************************************************************/
    clearCache: function () {

      // Release the entries and start the counters over
      state.cache.clear();
      state.hits = 0;
      state.misses = 0;
      state.evictions = 0;

    }

  };

  return Themer;

};/////////////////////////// createInterface END ///////////////////////////////



/////////////////////////// Private Functions START ////////////////////////////
const _Themer = {


  // ~~~~~~~~~~~~~~~~~~~~ Construction ~~~~~~~~~~~~~~~~~~~~
  // Wiring the pure parts together at loader time.

  /********************************************************************
  Build the pure parts, threading siblings through the container.

  Every part loader takes the uniform (shared_libs, config, errors)
  signature, so a part that needs a sibling receives it on the
  container rather than through a wider signature.

  @param {Object} Lib - Dependency container
  @param {Object} CONFIG - Merged config for this instance
  @param {Object} ERRORS - Frozen error catalog
  @param {Object} Validators - Validators singleton
  @param {Object} Color - Color part built by the loader

  @return {Object} - Map of part name to part interface
  *********************************************************************/
  buildParts: function (Lib, CONFIG, ERRORS, Validators, Color) {

    // Scale depends on nothing but Lib; color arrives already built
    const Scale = createScale(Lib, CONFIG, ERRORS);

    // Emit needs color to render shadow layers as rgba
    const emit_libs = Object.assign({}, Lib, { Color: Color });

    // Resolve needs color for contrast, scale for generators, and the validators
    const resolve_libs = Object.assign({}, Lib, {
      Color: Color,
      Scale: Scale,
      Validators: Validators
    });

    return {
      Color: Color,
      Scale: Scale,
      Emit: createEmit(emit_libs, CONFIG, ERRORS),
      Resolve: createResolve(resolve_libs, CONFIG, ERRORS)
    };

  },


  // ~~~~~~~~~~~~~~~~~~~~ The Adaptive Cascade ~~~~~~~~~~~~~~~~~~~~
  // Turning the caller's variant selection into real layers (v9).

  /********************************************************************
  Prepend the selected template variants to the caller's layer stack.

  A variant entry is a plain `{ tokens: {...} }` pin bundle the template
  declares under `variants`; the `variant` option selects by form and
  platform, and `adaptive: 'fixed'` (or no selection) leaves the stack
  untouched. The form variant lands first, the platform variant second,
  so a platform pin refines a form pin and a caller layer outranks both.

  @param {Object} Lib - Shared dependency container
  @param {Object} template - The template being resolved
  @param {Object[]} layers - Ordered sparse overlays
  @param {Object} [options] - Per-call overrides

  @return {Object[]} - The layer stack resolution applies
  *********************************************************************/
  effectiveLayers: function (Lib, template, layers, options) {

    // A fixed theme, or no selection, leaves the caller's cascade alone
    if (Lib.Utils.isNullOrUndefined(options)
        || options.adaptive === 'fixed'
        || Lib.Utils.isNullOrUndefined(options.variant)
        || Lib.Utils.isNullOrUndefined(template.variants)) {
      return layers;
    }

    const variant = options.variant;
    const variants = template.variants;
    const out = [];

    // Form first, platform second; a variant the template does not declare
    // drops out rather than failing - the caller's own layers still win
    if (!Lib.Utils.isNullOrUndefined(variant.form)) {
      const form = variants['form.' + variant.form];
      if (!Lib.Utils.isNullOrUndefined(form)) {
        out.push(form);
      }
    }
    if (!Lib.Utils.isNullOrUndefined(variant.platform)) {
      const platform = variants['platform.' + variant.platform];
      if (!Lib.Utils.isNullOrUndefined(platform)) {
        out.push(platform);
      }
    }

    return out.concat(layers);

  },


  /********************************************************************
  The options the resolve part receives: the call's options minus the
  adaptive keys, which the cascade above already consumed.

  @param {Object} Lib - Shared dependency container
  @param {Object} [options] - Per-call overrides

  @return {Object|undefined} - Options without variant or adaptive
  *********************************************************************/
  resolveOptions: function (Lib, options) {

    if (Lib.Utils.isNullOrUndefined(options)) {
      return options;
    }
    if (Lib.Utils.isNullOrUndefined(options.variant) && Lib.Utils.isNullOrUndefined(options.adaptive)) {
      return options;
    }

    const out = Object.assign({}, options);
    delete out.variant;
    delete out.adaptive;

    return out;

  },


  // ~~~~~~~~~~~~~~~~~~~~ Projection ~~~~~~~~~~~~~~~~~~~~
  // Walking a resolved map through one platform's emitters.

  /********************************************************************
  Project every resolved token onto one platform.

  @param {Object} Lib - Dependency container
  @param {Object} Parts - Pure parts
  @param {Object} CONFIG - Merged config for this instance
  @param {Object} resolved - Output of resolve
  @param {Object} template - The template that produced it
  @param {String} platform - Target platform

  @return {Object} - Emitted result with its two reports
  *********************************************************************/
  project: function (Lib, Parts, CONFIG, resolved, template, platform) {

    // The template's own base size wins, so one template can restate the root
    const scales = resolved.scales || {};
    const base_font_size = scales.base_font_size || CONFIG.BASE_FONT_SIZE;

    const meta = template.meta || {};
    const supported = Parts.Emit.platforms();
    const out = {};
    const substituted = [];
    const lossy = [];

    // Project each token through the emitter its group names
    const names = Object.keys(resolved.tokens);

    for (let i = 0; i < names.length; i++) {
      _Themer.projectOne(Lib, Parts, names[i], resolved, meta, platform, supported, base_font_size, out, substituted, lossy);
    }

    return {
      tokens: out,
      substituted: substituted,
      lossy: lossy
    };

  },


  /********************************************************************
  Project one token, recording a substitution when the platform
  cannot carry it at all.

  @param {Object} Lib - Dependency container
  @param {Object} Parts - Pure parts
  @param {String} name - Token name
  @param {Object} resolved - Output of resolve
  @param {Object} meta - Template metadata
  @param {String} platform - Target platform
  @param {String[]} supported - Every platform this engine emits for
  @param {Number} base_font_size - Root size for rem conversion
  @param {Object} out - Accumulated emitted tokens
  @param {Object[]} substituted - Accumulated substitution reports
  @param {Object[]} lossy - Accumulated loss reports

  @return {void}
  *********************************************************************/
  projectOne: function (Lib, Parts, name, resolved, meta, platform, supported, base_font_size, out, substituted, lossy) {

    // A token with no metadata passes through as a raw value
    const entry_meta = meta[name] || { group: 'raw' };
    const platforms = entry_meta.platforms || supported;
    const value = resolved.tokens[name];

    // Unavailable here, so emit the declared fallback rather than omitting the
    // key. Omitting it would force every caller to guard against undefined,
    // and a value that vanishes with no record is exactly what this reports.
    if (!Lib.Utils.inArray(platforms, platform)) {
      out[name] = entry_meta.fallback ? entry_meta.fallback[platform] : null;

      substituted.push({
        token: name,
        declared: value,
        fallback: out[name]
      });

      return;
    }

    // The token name travels with the context so a lossy emitter can name it.
    const context = {
      base_font_size: base_font_size,
      token: name,
      lossy: lossy
    };

    out[name] = Parts.Emit.value(value, entry_meta.group, platform, context);

  },


  /********************************************************************
  Derive the level-2 and level-3 readings of the leveled tokens.

  A token enters a level map only when its effective authored value is an
  alias whose chain reaches a member of a contract leveled set. Its value
  at level N is the resolved value of the member shifted N - 1 places
  along its set, capped at the last member, emitted for the same
  platform. A literal, a composite, or a chain that never names a set
  member leaves the token out of both maps.

  @param {Object} Lib - Dependency container
  @param {Object} Parts - Pure parts
  @param {Object} CONFIG - Merged config for this instance
  @param {Object} template - The authored template the chains read
  @param {Object[]} layers - Ordered sparse overlays; their pins win in
    order, so the chains read the cascade resolve saw
  @param {Object} resolved - Output of resolve, holding every member's value
  @param {String} platform - Target platform
  @param {Object[]} level_lossy - Accumulated loss reports for level reads

  @return {Object} - { 2: {...}, 3: {...} } maps of token name to value
  *********************************************************************/
  buildLevels: function (Lib, Parts, CONFIG, template, layers, resolved, platform, level_lossy) {

    const levels = { 2: {}, 3: {} };
    // The effective authored map: the template's tokens with each layer's
    // pins applied in order, the last pin winning - the same cascade
    // resolve applied, so a pinned literal stops a chain and a pinned
    // alias redirects it
    const tokens = Object.assign({}, template.tokens);
    for (let i = 0; i < layers.length; i++) {
      const pins = layers[i].tokens || {};
      const names = Object.keys(pins);
      for (let j = 0; j < names.length; j++) {
        tokens[names[j]] = pins[names[j]];
      }
    }
    const meta = template.meta || {};
    const supported = Parts.Emit.platforms();
    const scales = resolved.scales || {};
    const base_font_size = scales.base_font_size || CONFIG.BASE_FONT_SIZE;

    const isAlias = function (entry) {
      return Lib.Utils.isString(entry) && entry.charAt(0) === '{' && entry.charAt(entry.length - 1) === '}';
    };

    for (const name of Object.keys(tokens)) {

      // Only an alias can reach a leveled member; walk its chain to the
      // first one it names
      if (!isAlias(tokens[name])) {
        continue;
      }
      const seen = {};
      let member = null;
      let cursor = tokens[name].slice(1, -1);
      while (cursor !== null && !seen[cursor]) {
        seen[cursor] = true;
        const bare = cursor.indexOf('color.') === 0 ? cursor.slice(6) : null;
        if (bare !== null && contract.leveled_index[bare]) {
          member = bare;
          break;
        }
        cursor = isAlias(tokens[cursor]) ? tokens[cursor].slice(1, -1) : null;
      }
      if (member === null) {
        continue;
      }

      // Emit the shifted member's resolved value under this token's meta
      const hit = contract.leveled_index[member];
      const members = contract.leveled[hit.set];
      const entry_meta = meta[name] || { group: 'raw' };
      const platforms = entry_meta.platforms || supported;
      const context = { base_font_size: base_font_size, token: name, lossy: level_lossy };
      for (const level of [2, 3]) {
        const shifted = 'color.' + members[Math.min(hit.index + level - 1, members.length - 1)];
        if (resolved.tokens[shifted] === undefined) {
          continue;
        }
        if (!Lib.Utils.inArray(platforms, platform)) {
          levels[level][name] = entry_meta.fallback ? entry_meta.fallback[platform] : null;
          continue;
        }
        levels[level][name] = Parts.Emit.value(resolved.tokens[shifted], entry_meta.group, platform, context);
      }

    }

    return levels;

  },


  // ~~~~~~~~~~~~~~~~~~~~ Result Cache ~~~~~~~~~~~~~~~~~~~~
  // A bounded, least-recently-used cache over the two derivation stages. The
  // key is deliberately hybrid, because the inputs have opposite lifetimes: a
  // template is a long-lived import, so it is keyed by identity, while a layer
  // stack is rebuilt on every render, so it is keyed by content.

  /********************************************************************
  Build the cache key for a resolve call.

  Hashing the template instead of keying it by identity would make
  the hit path scale with token count, costing more than the
  derivation it avoids. Keying on the layers alone would be wrong
  rather than merely slow: a second template with the same layers
  would receive the first template's result.

  @param {Object} state - Per-instance state
  @param {Object} template - The template being resolved
  @param {Object[]} layers - Ordered sparse overlays
  @param {Object} options - Per-call overrides

  @return {String} - Cache key
  *********************************************************************/
  resolveKey: function (state, template, layers, options) {

    // Options join the key because they change the result
    return _Themer.idOf(state, template)
      + '|resolve|' + JSON.stringify(layers)
      + '|' + JSON.stringify(options === undefined ? null : options);

  },


  /********************************************************************
  Build the cache key for an emit call.

  Keyed on the resolved object's identity, the template's identity,
  and the platform. A cached resolve returns the same reference, so
  identity is already an exact proxy for content here, and serializing
  a whole token map per call would cost more than the projection it
  avoids.

  Template identity joins the key because template metadata drives
  emitter selection. Two templates producing the same resolved values
  but with different metadata may emit differently.

  A hand-built resolved object gets a fresh id and simply misses
  every time, which is correct but uncached.

  @param {Object} state - Per-instance state
  @param {Object} resolved - Output of resolve
  @param {Object} template - The template that produced the resolved values
  @param {String} platform - Target platform

  @return {String} - Cache key
  *********************************************************************/
  emitKey: function (state, resolved, template, platform) {

    // Platform and template identity join the key so different targets
    // or different templates never serve each other's result
    return _Themer.idOf(state, resolved)
      + '|' + _Themer.idOf(state, template)
      + '|emit|' + platform;

  },


  /********************************************************************
  Assign a short stable id to an object, by identity.

  The ids live in a WeakMap, so a discarded template is collectable
  and takes its id with it.

  @param {Object} state - Per-instance state
  @param {Object} object - Object to identify

  @return {String} - Stable id for this object
  *********************************************************************/
  idOf: function (state, object) {

    // Mint an id the first time this object is seen
    if (!state.object_ids.has(object)) {
      state.object_ids.set(object, 'o' + state.next_object_id);
      state.next_object_id++;
    }

    return state.object_ids.get(object);

  },


  /********************************************************************
  Read a cache entry, refreshing its recency on a hit.

  @param {Object} state - Per-instance state
  @param {String} key - Cache key

  @return {*} - The cached value, or undefined on a miss
  *********************************************************************/
  getCache: function (state, key) {

    // Count the miss and let the caller derive
    if (!state.cache.has(key)) {
      state.misses++;

      return undefined;
    }

    // Re-insert so insertion order stays recency order, which is what makes
    // this least-recently-used rather than first-in-first-out
    const value = state.cache.get(key);
    state.cache.delete(key);
    state.cache.set(key, value);
    state.hits++;

    return value;

  },


  /********************************************************************
  Store a cache entry, evicting the oldest when at capacity.

  @param {Object} state - Per-instance state
  @param {Object} CONFIG - Merged config for this instance
  @param {String} key - Cache key
  @param {*} value - Value to store

  @return {void}
  *********************************************************************/
  writeCache: function (state, CONFIG, key, value) {

    // Storing nothing keeps every call cold, which is what the toggle is for
    if (CONFIG.CACHE_ENABLED !== true) {
      return;
    }

    // Drop the oldest entry when this insert would exceed the bound
    if (!state.cache.has(key) && state.cache.size >= CONFIG.CACHE_CAPACITY) {
      state.cache.delete(state.cache.keys().next().value);
      state.evictions++;
    }

    state.cache.set(key, value);

  }

};/////////////////////////// Private Functions END /////////////////////////////
