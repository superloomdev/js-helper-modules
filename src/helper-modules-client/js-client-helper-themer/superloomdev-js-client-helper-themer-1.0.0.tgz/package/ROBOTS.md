# ROBOTS.md - helper-themer

> Compact signature reference for AI agents. Read this before calling any function in this module.

**Module:** `@superloomdev/js-client-helper-themer` | **Alias:** `helper-themer` | **Class:** G (pure engine, factory) | **Runtime:** Node.js 24+, React Native (Hermes)

## Load

```javascript
import themer from 'helper-themer';

Lib.Themer = themer(Lib, CONFIG);
```

Factory. Each call returns an independent instance with its own cache. `Lib` must carry `Utils` and `Debug`.

## Peer Dependencies

| Package | Range |
|---|---|
| `helper-utils` | `^1.0.0` |
| `helper-debug` | `^1.0.0` |

Not a dependency: `helper-font`. The two modules are independent by design.

## CONFIG

| Key | Type | Default | Constraint |
|---|---|---|---|
| `BASE_FONT_SIZE` | Number | `16` | `> 0` |
| `CACHE_CAPACITY` | Number | `32` | whole, `>= 1` |
| `CACHE_ENABLED` | Boolean | `true` | strict boolean |
| `MIN_CONTRAST_RATIO` | Number | `4.5` | `1` to `21` |
| `DEFAULT_TYPE_SCALE` | String | `'stepPairIncrement'` | Must name a generator this engine provides |
| `SCALE_GENERATORS` | Object | `{}` | Custom scale generator overrides |

Validated at load. Bad config throws immediately.

## Signatures

```javascript
buildTheme(template, layers, platform, options?) -> { tokens, substituted, lossy, corrections, violations, stats }
resolve(template, layers, options?)              -> { tokens, scales, polarity, anchor_index, motion_factor, contrast_mode, stats, corrections, violations }
emit(resolved, template, platform, options?)     -> { tokens, substituted, lossy }
validateTemplate(template)                       -> { success, errors }
getContract()                                    -> Object
validateContract(theme, options?)                -> { success, errors, warnings }
auditRoles(theme)                                -> { success, findings }
getPlatforms()                                   -> ['web', 'native']
getCacheStats()                                  -> { hits, misses, evictions, size }
clearCache()                                     -> undefined
```

`platform` is `'web'` or `'native'`. `layers` is always an array, never a single object.

## Token Contract

The engine core is vocabulary-agnostic: buildTheme accepts any token names. Superloom's
vocabulary, the token contract, ships in this package as data and is read through three functions.

getContract() -> Object | async:no
  Frozen registry { version, groups, tokens, meta }. tokens has one entry per contract token
  ({ group, emit?, values? }); meta is derived and can be attached to a template as template.meta.
  Same reference on every call. Never throws. Version 7 has 1133 tokens in 19 groups (the role grid,
  `contract.grid`, now 623 cells): version 6's 995 plus the divider, link, loading, progress step,
  skeleton and view families, member cells for the button set, button skeleton, combo button,
  inline loading, saving, the tag variants and the landing view, one button kind (`quick_action`),
  three anatomy values (`loading_motion`, `tag_close`, `tag_selected_mark`), the grid's first
  motion cells (`loading_rotation`, `loading_arc_cycle`, `skeleton_cycle`) and the icon role
  `save`.

validateContract(theme, options) -> { success, errors, warnings } | async:no
  Checks theme.tokens against the contract. options.required (string[]) makes absence an error;
  options.supported (string[]) makes presence-without-support a warning. Entries are
  { code, token, message } with codes CONTRACT_MISSING_TOKEN, CONTRACT_UNKNOWN_TOKEN,
  CONTRACT_INVALID_VALUE (errors) and CONTRACT_UNSUPPORTED_TOKEN (warnings). success is true when
  errors is empty. Structure and routes are validateTemplate's job; this function checks names and
  literal value types only. Alias strings are accepted for every type. Throws TypeError only when theme,
  theme.tokens, options.required, or options.supported is malformed; every content finding is reported.

auditRoles(theme) -> { success, findings } | async:no
  Checks a built theme's color roles against the engine's role rules (themer.roles.js): every
  content role reads on its surface role at the rule's minimum ratio (a translucent content color
  is composited on the surface, a translucent surface on color.background); roles that mean
  different things resolve to different values (a danger fill equal to the disabled fill is a
  danger button that reads as disabled; a selected surface equal to the page), and when
  feedback.press is highlight every hover and active fill differs from its rest fill; every
  shadow.level_* is translucent. findings entries are
  { rule: 'contrast', tokens: [content, surface], ratio, minimum } | { rule: 'distinct', tokens, value }
  | { rule: 'shadow', tokens: [level], value } | { rule: 'missing', tokens: [name] }. Placeholder text
  is not a rule: a reference system draws it below 4.5 by design. Throws TypeError only when theme
  or theme.tokens is malformed. A template's tests run this over every built scheme.

## Failure Model

**Everything throws `TypeError`. There is no operational envelope.**

The single exception is `validateTemplate`, which returns `{ success, errors }` and never throws. It is a pre-resolution reporting surface, so it collects every finding. `validateContract` returns `{ success, errors, warnings }` for content findings but throws `TypeError` only when `theme`, `theme.tokens`, `options.required`, or `options.supported` is malformed.

Message format: `[helper-themer] <field-path> <expected-shape>`

| Trigger | Message |
|---|---|
| non-object template | `template must be a plain object` |
| missing token map | `template.tokens must be a plain object` |
| non-array layers | `layers must be an array of layer objects` |
| bad layer entry | `layers[1] must be a plain object` |
| alias to nothing | `tokens.X must be a declared token or alias target` |
| alias loop | `tokens.X resolves through an alias cycle` |
| unknown scale | `tokens.X.scale must name a generator this engine provides` |
| unknown operation | `tokens.X.op must name an operation this engine provides` |
| unknown platform | `platform must be one of: web, native` |
| unknown group | `tokens.X (group: Y) must name a known emitter group` |

## Naming Rule (important)

| Surface | Case |
|---|---|
| Template / layer / options / result keys | `snake_case` |
| Scale and operation identifiers | camelCase (stepPairIncrement, miniUnit, geometric, rampStep, hue, mix, scaleBy, alpha) |
| Keys **inside** an emitted token value | `camelCase` (`fontSize`, `lineHeight`, `boxShadow`) - React Native's contract, do not rename |

## Template Entry Shapes

```javascript
'#0f62fe'                                                    // literal
'{brand}'                                                    // alias
{ op: 'rampStep', args: [5] }                                // rule
{ scale: 'miniUnit', multiplier: 2 }                         // generator
{ type_set: true, step: 1, weight: 400, line_height: 1.33,
  letter_spacing: 0.32, font_family: 'mono' }                // scale-derived type set
{ type_set: true, font_size: 14.5, line_height_px: 20.25 }   // exact type set
{ shadow: true, layers: [ { x: 0, y: 2, blur: 4, spread: 3, color: '#00000033', inset: false } ] }  // shadow
{ viewport: true, vw: 2 }                                    // viewport literal (v2)
{ spring: true, stiffness: 700, damping: 47.62, mass: 1 }   // spring literal (v2)
{ segments: true, curves: [[0.5, [0.05, 0.7, 0.1, 1]], [1, [0.3, 0, 0.8, 0.15]]] }  // segments literal (v2)
{ icon: true, viewBox: '0 0 32 32', paths: [{ d: 'M8 8h16v16H8z' }],
  sizes: { '16': { viewBox: '0 0 16 16', paths: [{ d: 'M4 4h8v8H4z' }] } } }  // icon literal (v4)
```

Type set and shadow require their boolean marker. Shadow must declare `layers`, an array of
`{ x, y, blur, spread, color, inset? }` objects.

## Metadata Groups

`color`, `dimension`, `fontSize`, `letterSpacing`, `duration`, `easing`, `typeSet`, `shadow`, `raw`, `spring`, `viewport`.

A token with no `meta` entry defaults to `raw`. A token with a `platforms` list that excludes a platform **must** declare `fallback` for it. An unknown `group` is a build-time `TypeError` naming every offending token, not a silent pass-through.

## Layer Fields

`name`, `tokens`, `scales`, `polarity` (`'light'`/`'dark'`), `motion_factor` (`0`-`1`, scales the `duration` group).

## Options

`contrast` (`'correct'` rewrites, anything else only reports), `min_contrast_ratio`, `motion_factor`. An explicit `motion_factor`, including zero, overrides the layer stack. Any other key throws.

## Gotchas

- **`resolve` returns a cached object by reference.** Do not mutate the result; a later hit sees the mutation
- **A hand-built `resolved` object misses the emit cache every time.** Correct, just uncached
- **`font_family` is a token, never a family name and never a CSS font stack.** The engine passes it through untranslated; React Native cannot represent a fallback list
- **An absent `weight` stays absent.** Do not `String()` it blindly; that emits the literal `'undefined'`
- **Both platforms emit identical token keys.** Never guard against a missing key; check `substituted` instead
- **`lossy` and `substituted` are return values, not warnings.** The caller decides whether they are fatal
- **Contrast correction can override an explicit pin.** A tenant's brand color may be altered; use `{ contrast: 'report' }` at build time to see it instead
- **The engine does no I/O.** It never fetches a theme, loads a font, or reads the DOM

## Testing

```bash
cd _test && npm install && npm test
```

Pure Node. No container, no emulator, no network, no environment variables.
