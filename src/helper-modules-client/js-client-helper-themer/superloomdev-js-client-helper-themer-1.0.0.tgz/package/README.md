# @superloomdev/js-client-helper-themer

A design-token engine that derives a complete theme from a template plus a cascade of layers, then delivers it to web and React Native from one resolved source.

A theme is a **derivation**, not a list. A template declares what tokens exist and how each is produced; a theme supplies only the values that differ. A theme pinning four seeds and a theme pinning every value are the same object on the same code path.

## Features

- **One derivation, two platforms.** Resolve produces canonical, unit-free values; emit projects them onto web or React Native. No second theme to keep in step
- **Six resolution routes.** Literal, alias, rule, generator, type set, and shadow, freely mixed, with nothing downstream able to tell which one produced a value
- **Layer cascade, not modes.** Dark mode, density, tenant brand, and reduced motion are sparse layers that compose, so nobody enumerates the combinations
- **Nothing disappears quietly.** A token a platform cannot carry takes a declared fallback; a fact a projection cannot represent is reported. Both come back as ordinary return values
- **Contrast enforcement built in.** Runs after resolution so it covers every route, corrects by snapping inside the palette, and reports in both modes
- **Pure and synchronous.** No I/O, no network, no React, no DOM. A theme is ready in the same tick
- **Bounded result cache** per instance, keyed so a framework provider's freshly built layer array still hits

## Installation

```bash
npm install @superloomdev/js-client-helper-themer
```

Published to GitHub Packages under the `@superloomdev` scope. Registry setup is a one-time step: see [npmrc setup](https://github.com/superloomdev/superloom/blob/main/docs/dev/npmrc-setup.md).

## Quick Start

```javascript
import helperUtils from 'helper-utils';
import helperDebug from 'helper-debug';
import themer from 'helper-themer';

const Lib = {};
Lib.Utils = helperUtils(Lib, {});
Lib.Debug = helperDebug(Lib, {});

Lib.Themer = themer(Lib, {});

const theme = Lib.Themer.buildTheme(template, [
  { name: 'brand', tokens: { brand: '#0f62fe' } },
  { name: 'dark', polarity: 'dark' }
], 'web');

theme.tokens.spacing03;   // '1rem'
theme.tokens.brand;       // '#0f62fe'
```

The same call with `'native'` returns `16` for `spacing03`, from the same derivation.

## Core Concepts

### Resolve, then emit

Resolution is platform independent and produces a spacing token as the number `16`. Emit projects it: `'1rem'` on web, `16` on native. The difference between platforms lives in one table rather than scattered through the token values.

This is also why a type set resolves to an **object**. React Native needs an absolute line height, which is the font size times the ratio; because both are inside the same object, emit never reaches across tokens.

### Layers

Layers apply in order and the last to pin a token wins. Each pins only what it changes.

```javascript
[
  { name: 'base' },
  { name: 'compact', scales: { miniUnit: { base: 4 } } },
  { name: 'reduced', motion_factor: 0.5 }
]
```

Density is a one-number change. Reduced motion is a derivation over the durations the theme already has, not a second set.

### Reports, not silence

```javascript
const native = Themer.emit(resolved, template, 'native');

native.substituted;  // tokens the platform cannot carry, and their fallback
native.lossy;        // facts the projection could not represent, and why
```

Both platforms emit the same token keys, so no caller has to guard against `undefined`.

## API Overview

| Function | Purpose |
|---|---|
| `buildTheme(template, layers, platform, options)` | Derive and emit in one call |
| `resolve(template, layers, options)` | Derive a platform-independent token map |
| `emit(resolved, template, platform, options)` | Project a resolved map onto one platform with validated emission options |
| `validateTemplate(template)` | Check a template and report every finding |
| `getContract()` | Return the frozen token contract registry |
| `validateContract(theme, options)` | Check theme tokens against the contract |
| `auditRoles(theme)` | Check a built theme's color roles: contrast, distinctness, translucent shadows |
| `getPlatforms()` | List the platforms this engine emits for |
| `getCacheStats()` / `clearCache()` | Inspect and reset the per-instance cache |

Full signatures and return shapes: [API Reference](docs/api.md).

## Token Contract

The engine core is vocabulary-agnostic: buildTheme accepts any token names. Superloom's
vocabulary, the token contract, ships in this package as data and is read through three functions.

getContract() -> Object | async:no
  Frozen registry { version, groups, tokens, meta }. tokens has one entry per contract token
  ({ group, emit?, values? }); meta is derived and can be attached to a template as template.meta.
  Same reference on every call. Never throws.

validateContract(theme, options) -> { success, errors, warnings } | async:no
  Checks theme.tokens against the contract. options.required (string[]) makes absence an error;
  options.supported (string[]) makes presence-without-support a warning. Entries are
  { code, token, message } with codes CONTRACT_MISSING_TOKEN, CONTRACT_UNKNOWN_TOKEN,
  CONTRACT_INVALID_VALUE (errors) and CONTRACT_UNSUPPORTED_TOKEN (warnings). success is true when
  errors is empty. Structure and routes are validateTemplate's job; this function checks names and
  literal value types only. Alias strings are accepted for every type. Throws TypeError only when theme,
  theme.tokens, options.required, or options.supported is malformed; every content finding is reported.

auditRoles(theme) -> { success, findings } | async:no
  Checks a built theme's color roles against the engine's role rules: every content role reads on
  its surface role (4.5 for text, 3.0 for icons and boundaries), roles that mean different things
  differ, every shadow level is translucent. A template's tests run it over every scheme so a value
  that would draw an unreadable label is caught before any component draws it.

### Contract version 7

Version 7 extends the role grid to the remaining atom-tier components: the divider, link, loading, progress step, skeleton and view families, plus member cells where one member of an existing family draws differently (the button set, the button skeleton, the combo button, the inline loading line, the saving status, the closable, interactive, selectable and skeleton tags, the landing view):

- **New grid families** (134 cells added, 623 total): `divider` (line color, width, inset); `link` (label colors per rest, hover, active, visited and disabled state, the focus ring color and width, icon gap and sizes, three type sets); `loading` (indicator, track and scrim colors; size, stroke width and arc per size; the `motion` group's first cells: `loading_rotation` and `loading_arc_cycle`); `progress_step` (icon, line and label colors per state, eleven geometry controls, two type sets); `skeleton` (container and shimmer colors, radius, placeholder and text geometry, `motion.skeleton_cycle`); `view` (background and navigation background colors).
- **New member cells:** `button_set_separator[_disabled|_stacked_disabled]`, `button_set_item_max_width`, `button_set_gap`, `button_set_fluid_*`; `button_skeleton_width`; `combo_button_min_width` and `_max_width`; `inline_loading_label`, `inline_loading_success`, `inline_loading_error`, `control.inline_loading_gap`, `type.inline_loading_label`; `saving_error_icon`, `control.saving_icon_gap`, `type.saving_label`; `tag_close_*` for the closable tag, `tag_interactive_*` and `tag_focus_*` for the interactive tags, `tag_selectable_*` for the selectable tag, `tag_skeleton_width`; `landing_banner`, the landing geometry controls and `type.landing_title`.
- **New button kind** `quick_action`: the chat button's outlined quick action, which gets every cell a kind gets plus `control.button_quick_action_focus_gap_width`.
- **New anatomy values** (3): `anatomy.loading_motion` (`spin` | `arc`), `anatomy.tag_close` (`circle` | `inset`), `anatomy.tag_selected_mark` (`shown` | `hidden`).
- **New icon role:** `icon.save` (the saving status's glyph).
- **Batch-6 amendment** (6 cells): the progress step's `focus_width`, `vertical_icon_top`, `vertical_line_width` and `secondary_label_top` / `_start`, and the selectable tag's own pressed layer `color.tag_selectable_layer_active`.
- **New role audits:** `link_label[_hover|_visited]`, `progress_step_label` and `inline_loading_label` must read on the page at 4.5, the selectable tag's labels must read on their rest and selected fills, `skeleton_shimmer` must differ from `skeleton_container`, and the selectable tag's selected pair must not paint exactly as its rest pair.

The contract registry now carries 1133 tokens in 19 groups.

### Contract version 6

Version 6 extends the role grid to the next component batch, so the same families hold for a Select's option list, a menu, a switch, a tag, a progress bar, a tooltip, tabs, a dialog and a toast notification:

- **New grid families** (`color`, `control`, `type`, `shadow` cells, 191 cells added for 460 total): `list` (the option list, shared by Select, Dropdown, Menu and ComboBox, with `menu_*` member cells), `switch`, `tag` (the neutral chrome; the ten `color.tag_*_<hue>` semantic colors stay), `progress`, `tooltip` (with `tooltip_compact_*` members), `tab` (with `tab_contained_*` members), `dialog`, `notification`.
- **New member cells:** `text_area_container_hover`, `text_area_outline_disabled`, `type.text_area_value`; `radio_size`, `radio_border`, `radio_dot_size`, `radio_focus_offset`, `radio_outline_selected[_hover|_active|_focus]`; `icon_button_size`, `icon_button_icon_size`, `icon_button_<kind>_icon[_state]`; `dialog_close_icon_size`. Amended inside the version: `menu_divider`; `dialog_header_space`, `dialog_min_height`; `tab_contained_height`, `tab_contained_padding_block`, `tab_item_gap`; `menu_min_width`, `menu_icon_min_width`, `menu_item_gap`, `menu_item_icon[_hover|_disabled]`; `type.menu_item_shortcut` and `color.menu_item_shortcut[_hover]` (the menu item shortcut's own type and ink: the primary draws it in the item's type and colour, the second in a smaller supporting type and a quieter ink); and the icon button's selected paints as member cells (`icon_button_<kind>_container_selected` for every kind, `icon_button_<kind>_icon_selected` for primary and secondary) and the toggle's unselected face (`icon_button_<kind>_container_unselected`, `icon_button_<kind>_icon_unselected` for every kind): a selected filled or tonal icon button paints the button's face, so its selected pair is audited against the unselected pair.
- **New anatomy values** (6): `anatomy.field_counter` (`label` | `message`), `anatomy.switch_state_text` (`shown` | `hidden`), `anatomy.progress_indeterminate` (`sweep` | `travel`), `anatomy.tab_indicator` (`full` | `content`), `anatomy.dialog_close` (`shown` | `hidden`), and, amended inside the version, `anatomy.list_selected_mark` (`shown` | `hidden`): whether a selected list item draws its mark at all; `anatomy.switch_edge` (`border` | `skin`): whether a switch's edge is a drawn border that costs room or a skin it paints free; `anatomy.dialog_label` (`shown` | `hidden`): whether a dialog draws an eyebrow label above its heading; `anatomy.menu_icon_seat` (`shared` | `item`): whether a menu with any icon reserves the icon seat for every item or each item carries its own; `anatomy.field_counter_format` (`tight` | `spaced`): whether a field's counter prints the count against the limit ("4/100") or spaced from it ("4 / 100").
- **New icon roles** (2): `icon.selected_indicator` (the mark on a selected list item), `icon.switch_checked_indicator` (the mark on a checked switch handle).

The contract registry now carries 995 tokens in 19 groups.

### Contract version 5

Version 5 adds per-component roles, so a component reads one role and each template answers it with its own number where the shared scales hold one value for every design system:

- **`control`** (structure tier, `number`, emit `dimension`, 11 tokens): `control.button_height`, `control.button_radius`, `control.button_padding_start`, `control.button_padding_end`, `control.button_icon_size`, `control.field_height`, `control.field_radius`, `control.field_icon_size`, `control.checkbox_size`, `control.checkbox_border`, `control.option_height`. A number on native, a `rem` string on web, like `size.*`.
- **Role type sets** (`type` group, 2 tokens): `type.button_label`, the set a button label is drawn in; `type.field_label_raised`, the set a floating field label is drawn in once raised.
- **Role colors** (`color` group, 8 tokens): `color.button_tonal`, `color.button_tonal_hover`, `color.button_tonal_active`, `color.text_on_button_tonal`, `color.button_elevated`, `color.button_elevated_hover`, `color.button_elevated_active`, `color.control_checked` (the fill of a checked checkbox or radio).

The contract registry now carries 763 tokens in 19 groups. Contract version 5 was amended inside its milestone with the role grid (`contract.grid`, 269 cells marked `grid: true`): for the `field` family (TextInput, Select and later field-like components), each `button` kind and the `selection` family, one role per part a component draws, per state, per property (color, width, space, type set, elevation). A member cell (`text_input_container_hover`, `select_outline_disabled`, `select_indicator_focus`) exists only where a reference gives one member a different value. It also adds `shadow.level_00` (no elevation), `feedback.focus_trigger` (`any` | `keyboard`) and the icon roles `invalid`, `dropdown_indicator`, `checked_indicator` and `mixed_indicator`, and removes `anatomy.caret` (the glyph a part shows is an icon role, never an enum) and `feedback.focus` (each family's ring is its grid cells; a negative offset draws it inside the edge). A second amendment adds `anatomy.button_label` (`top` | `center`): where a button taller than the default height draws its label.

### Contract version 4

Version 4 adds two groups, so a template is theme plus icons and a component system holds no glyph or shape choice of its own:

- **`anatomy`** (structure tier, `enum`, 5 tokens): `anatomy.label` (`above` | `floating`), `anatomy.switch_handle` (`fixed` | `grows`), `anatomy.status_marker` (`bar_icon` | `plain`), `anatomy.dialog_actions` (`stretched` | `trailing`), `anatomy.slider_handle` (`round` | `bar`). Each names a shape choice design systems answer differently; a component system implements every listed value and the template picks one.
- **`icon`** (value tier, `icon`, 78 tokens): one token per semantic glyph name, `icon.close`, `icon.chevron_down`, `icon.warning`, and so on, alphabetical. The value type is the **icon literal** `{ icon: true, viewBox, paths, sizes? }`: `viewBox` is four space-separated finite numbers with positive width and height; `paths` is a non-empty list of `{ d, fillRule? }` with non-empty `d` and `fillRule` one of `nonzero` or `evenodd`; `sizes`, when present, maps positive integer pixel sizes to variants `{ viewBox, paths }` of the same shape, each in its own coordinate space (an icon set's 16-pixel glyph is often drawn on a 16-unit grid). No other keys are allowed. Emit passes the literal through unchanged on both platforms; a brand layer overrides an icon like any other token. The contract registry now carries 469 tokens in 18 groups.

### Contract version 3

Version 3 adds the `stacking` structure group: `stacking.dropdown`, `stacking.modal`, `stacking.header`, `stacking.overlay`, and `stacking.floating`. These raw numeric tokens let each design-system template publish its surface order without a component library carrying a private z-index table. Version 3 carried 385 tokens in 16 groups.

Version 2 added the approved Section 14.5 items:

**Version 2 structure groups:**

- **C2 `grid`** (13 tokens): `grid.columns_sm`, `grid.columns_md`, `grid.columns_lg`, `grid.columns_xlg`, `grid.columns_max`, `grid.gutter`, `grid.gutter_condensed`, `grid.gutter_narrow`, `grid.margin_sm`, `grid.margin_md`, `grid.margin_lg`, `grid.margin_xlg`, `grid.margin_max`
- **M3 `state`** (6 tokens): `state.hover_opacity`, `state.focus_opacity`, `state.pressed_opacity`, `state.dragged_opacity`, `state.disabled_content_opacity`, `state.disabled_container_opacity`. The `state` group declares `range: [0, 1]`; values outside that range are rejected.
- **M5 `tint`** (5 tokens): `tint.level_01`, `tint.level_02`, `tint.level_03`, `tint.level_04`, `tint.level_05`. The `tint` group declares `range: [0, 1]`; values outside that range are rejected.

**New value types:**

- **C3 `viewport`**: `{ viewport: true, vw: Number }` with `vw` finite and >= 0. Four tokens: `spacing.fluid_01`, `spacing.fluid_02`, `spacing.fluid_03`, `spacing.fluid_04`. Web emit produces `'2vw'`; native emit returns the object unchanged.
- **M10 `spring`**: `{ spring: true, stiffness, damping, mass }` with all three finite and greater than zero. `damping` is a coefficient in React Native `Animated.spring` terms, not a damping ratio. Where source data provides a ratio, `damping = ratio * 2 * Math.sqrt(stiffness * mass)`. Six tokens: `motion.spring_spatial_default`, `motion.spring_spatial_fast`, `motion.spring_spatial_slow`, `motion.spring_effects_default`, `motion.spring_effects_fast`, `motion.spring_effects_slow`. Both platforms emit the object unchanged.
- **M11 `segments`**: `{ segments: true, curves: [[t, [x1, y1, x2, y2]], ...] }` with `t` finite in `[0, 1]`, strictly increasing, and each inner array exactly four finite numbers. No new token; the type is accepted on any `emit: 'easing'` token.

**Type-set `breakpoints` (C4):** A type set may carry an optional `breakpoints` object whose keys are breakpoint names and whose values are type-set field objects with the same field rules (minus `type_set` and nested `breakpoints`). Each breakpoint is resolved and emitted through the same projection as the base.

**Icon sizes (C5):** `size.icon_03`, `size.icon_04`.

**Border width rename (C14):** `border.width_03` was 4 and is now 3; the 4 moved to `border.width_04`. This is an intentional breaking rename.

**Shadow levels (M4):** `shadow.level_04`, `shadow.level_05`.

**Shape radii (M6):** `shape.radius_12`, `shape.radius_28`.

**Font weights (M8):** `font.weight.thin`, `font.weight.extralight`, `font.weight.medium`, `font.weight.extrabold`, `font.weight.black`.

**Focus enum (F1):** `feedback.focus` (`outline` | `inset` | `underline`), removed in the version 5 amendment: each family's focus ring is its role-grid cells, and `feedback.focus_trigger` (`any` | `keyboard`) decides when it shows.

**Duration slots (M9):** `motion.duration_fast_03`, `motion.duration_fast_04`, `motion.duration_moderate_03`, `motion.duration_moderate_04`, `motion.duration_slow_03`, `motion.duration_slow_04`, `motion.duration_extra_slow_01`, `motion.duration_extra_slow_02`, `motion.duration_extra_slow_03`, `motion.duration_extra_slow_04`.

**Linear easing (M9b):** `motion.easing_linear` with `emit: 'easing'`.

No new error codes: every new rejection reuses `CONTRACT_INVALID_VALUE`.

## Configuration

| Key | Default | Purpose |
|---|---|---|
| `BASE_FONT_SIZE` | `16` | Root size the web emitter divides by to produce rem |
| `CACHE_CAPACITY` | `32` | Maximum cached results per instance |
| `CACHE_ENABLED` | `true` | Set false to derive fresh every call |
| `MIN_CONTRAST_RATIO` | `4.5` | Default floor for contrast rules |
| `DEFAULT_TYPE_SCALE` | `'stepPairIncrement'` | Default scale for type sets that omit `scale` |
| `SCALE_GENERATORS` | `{}` | Custom scale generator overrides |

See [Configuration](docs/configuration.md).

## Fonts

This module decides which typeface text should use. It does **not** load it.

A type set carries a font family **token** such as `'mono'`, which the engine passes through untranslated. `helper-font` maps that token to a registered family and loads the file. **The two modules do not depend on each other**, and theming never waits on a font: text renders immediately in a fallback and swaps when the font module finishes. The single point of contact is name equality.

See [Philosophy](docs/philosophy.md).

## Error Handling

Every failure throws `TypeError`, because a pure engine has no operational failures. The exception is `validateTemplate`, which reports `{ success, errors }` so a build tool sees every problem at once. `validateContract` throws `TypeError` for malformed arguments and reports `{ success, errors, warnings }` for content findings.

```javascript
Themer.emit(resolved, template, 'android');
// TypeError: [helper-themer] platform must be one of: web, native
```

A theme document from a server is untrusted input: check it before calling `resolve`. See [Schemas](docs/schemas.md).

## Compatibility

Node.js 24+ and React Native (Hermes). No React, no DOM, no runtime dependencies outside the framework.

| Peer dependency | Range |
|---|---|
| `helper-utils` | `^1.0.0` |
| `helper-debug` | `^1.0.0` |

## Documentation

- [API Reference](docs/api.md) - every function and return shape
- [Template Reference](docs/template.md) - authoring a template
- [Schemas](docs/schemas.md) - the validated contracts
- [Configuration](docs/configuration.md) - config keys and integration
- [Philosophy](docs/philosophy.md) - why the engine is shaped this way
- [ROBOTS.md](ROBOTS.md) - compact signature reference for AI agents

## Testing

```bash
cd _test && npm install && npm test
```

Pure Node. No container, no emulator, no network, no environment variables.

## License

MIT
